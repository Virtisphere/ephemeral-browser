# Ephemeral Browser

A lightweight browser sandbox using Docker + Chromium + noVNC.
