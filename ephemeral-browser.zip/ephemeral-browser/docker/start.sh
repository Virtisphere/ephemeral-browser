#!/bin/bash

export DISPLAY=:1

Xvfb :1 -screen 0 1024x768x16 &

xfce4-session &

sudo -u chromeuser chromium-browser --no-sandbox --kiosk --disable-infobars &

x11vnc -display :1 -nopw -forever -shared -bg

/opt/novnc/utils/novnc_proxy --vnc localhost:5900 --listen 6080
