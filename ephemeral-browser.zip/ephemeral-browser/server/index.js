const express = require('express');
const Docker = require('dockerode');
const app = express();
const docker = new Docker();
const port = 3000;

let containers = {};
const SESSION_TTL_MS = 11 * 60 * 1000;

app.use(express.static('../frontend'));
app.use(express.json());

app.post('/api/start', async (req, res) => {
  const container = await docker.createContainer({
    Image: 'ephemeral-browser',
    Tty: true,
    ExposedPorts: { '6080/tcp': {} },
    HostConfig: {
      AutoRemove: true,
      PortBindings: { '6080/tcp': [{ HostPort: '' }] }
    }
  });
  await container.start();
  const info = await container.inspect();
  const port = info.NetworkSettings.Ports['6080/tcp'][0].HostPort;

  const timeoutId = setTimeout(async () => {
    console.log(`Session timeout: destroying container ${container.id}`);
    try {
      await container.stop();
    } catch (err) {
      console.error('Error stopping container on timeout:', err.message);
    }
    delete containers[container.id];
  }, SESSION_TTL_MS);

  containers[container.id] = { instance: container, timeoutId };
  res.json({ id: container.id, port });
});

app.post('/api/terminate', async (req, res) => {
  const { id } = req.body;
  if (containers[id]) {
    clearTimeout(containers[id].timeoutId);
    try {
      await containers[id].instance.stop();
    } catch (err) {
      console.error('Error during manual container termination:', err.message);
    }
    delete containers[id];
  }
  res.json({ success: true });
});

app.listen(port, () => console.log(`API server on port ${port}`));
